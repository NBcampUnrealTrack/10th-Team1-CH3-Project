// 26/09/09 Copyright CH3 Team1 Jinho Song

#pragma once

// Core include
#include "CoreMinimal.h"

// Base include
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"

// UHT Header
#include "BTTaskPerceptionCheck.generated.h"

class ABOCharacter;

UCLASS()
class BEYONDOVERRIDE_API UBTTaskPerceptionCheck : public UBTTask_BlackboardBase
{
	GENERATED_BODY()

  public:
	UBTTaskPerceptionCheck();

  protected:
	// Task ���� �� ȣ��Ǵ� �Լ�
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

	void PerceptionCheck(UBehaviorTreeComponent& OwnerComp, ABOCharacter*& NearestTarget);
};
