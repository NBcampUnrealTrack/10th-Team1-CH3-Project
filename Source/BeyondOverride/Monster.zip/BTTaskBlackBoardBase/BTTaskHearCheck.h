// 26/09/12 Copyright CH3 Team1 Jinho Song

#pragma once

// Core include
#include "CoreMinimal.h"

// Base include
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"

// UHT Header
#include "BTTaskHearCheck.generated.h"

UCLASS()
class BEYONDOVERRIDE_API UBTTaskHearCheck : public UBTTask_BlackboardBase
{
	GENERATED_BODY()

  public:
	UBTTaskHearCheck();

  protected:
	// Task ���� �� ȣ��Ǵ� �Լ�
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
};
