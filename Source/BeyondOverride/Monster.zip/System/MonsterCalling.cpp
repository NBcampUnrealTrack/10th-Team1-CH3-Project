// 26/09/10 Copyright CH3 Team1 Jinho Song

// Base include
#include "Monster/System/MonsterCalling.h"

// Add include
#include "Engine/EngineTypes.h"
#include "Engine/OverlapResult.h"
#include "Engine/World.h"
#include "Monster/ActorComponent/ContinuousStateComponent.h"
#include "Monster/AiController/MonsterAIController.h"
#include "Monster/MonsterCharacter/MonsterCharacter.h"

void UMonsterCalling::CallMonsters(const FVector& CallCenter, float Radius, ABOCharacter*& Target, ECallType Type)
{

	const float CurrentTime = GetWorld()->GetTimeSeconds();

	// ��� �� ����� �迭
	TArray<FOverlapResult> OverlapResults;

	// Query ������ ����ü
	FCollisionObjectQueryParams ObjectQueryParams;

	// �ν��� Actor ���� ECC_Pawn
	ObjectQueryParams.AddObjectTypesToQuery(ECC_Pawn);

	FCollisionShape CollisionShape = FCollisionShape::MakeSphere(Radius);

	bool bHit = GetWorld()->OverlapMultiByObjectType(OverlapResults,
													 CallCenter,
													 FQuat::Identity,
													 ObjectQueryParams,
													 CollisionShape);

	for (const FOverlapResult& Result : OverlapResults)
	{
		AActor* Actor = Result.GetActor();

		if (!Actor)
		{
			continue;
		}

		AMonsterCharacter* CallTarget = Cast<AMonsterCharacter>(Actor);
		if (!CallTarget)
		{
			continue;
		}

		AMonsterAIController* Controller = Cast<AMonsterAIController>(CallTarget->GetController());
		if (!Controller)
		{
			continue;
		}

		if (Controller->GetState() == EMonsterState::Chase ||
			Controller->GetState() == EMonsterState::Attack ||
			Controller->GetState() == EMonsterState::StandOffMove ||
			Controller->GetState() == EMonsterState::StandOffWait)
		{
			continue;
		}

		Controller->PlantFlag(EFlag::Calling, CurrentTime);
		Controller->SetTarget(Target);

		if (Type == ECallType::LocationPatrol)
		{
			Controller->StateChange(EMonsterState::LocationPatrol, 10.0f);
		}
	}
}
