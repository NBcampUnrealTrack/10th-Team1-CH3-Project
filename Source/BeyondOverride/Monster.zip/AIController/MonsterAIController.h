// 26/09/09 Copyright CH3 Team1 Jinho Song

#pragma once

// Core include
#include "CoreMinimal.h"

// Base include
#include "AIController.h"

// Add include
#include "Monster/Enums/InfoEnums.h"
#include "Monster/Enums/StateEnums.h"
#include "Monster/Structs/StateParams.h"
#include "Perception/AIPerceptionTypes.h"

// UHT Header
#include "MonsterAIController.generated.h"

// ���� ����
class UAIPerceptionComponent;
class UAISenseConfig_Sight;
class UAISenseConfig_Hearing;
class UContinuousStateComponent;
class UShortTermStateComponent;
class USenseComponent;
class ABOCharacter;

UCLASS()
class BEYONDOVERRIDE_API AMonsterAIController : public AAIController
{
	GENERATED_BODY()

	// Methtods
  public:
	// ������
	AMonsterAIController();

	// BehaviorTree ���� �Լ�
	void EnableBehaviorTree();

	// Event

	void PlantFlag(FFlagInfo FlagInfo);

	void PlantFlag(EFlag State, float Time);

	void PlantFlag(EFlag State, float Time, bool Type);

	bool FoldFlags(EFlag Target);

	bool FoldFlags(EFlag Target, bool& Type);

	// Continuous State

	void OnStandOff();

	bool StandOffGetPosition() const;

	void StateChange(EMonsterState Input);

	void StateChange(EMonsterState Input, float HoldTime);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "MonsterState")
	EMonsterState GetState() const;

	EMonsterState GetBeforeState() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "MonsterState")
	bool IsContinueState() const;

	// Sense

	void SetTarget(ABOCharacter* Target);
	ABOCharacter* GetTarget() const;

	void SetTargetPoint(FVector Point);
	FVector GetTargetPoint() const;

	void SetEQSPoint(FVector Point);
	FVector GetEQSPoint() const;

	FVector GetSpawnPoint() const;

	void FocusSetUp(const EMonsterState& input);

  protected:
	virtual void BeginPlay() override;

	virtual void PostInitializeComponents() override;

	UFUNCTION()
	void OnTargetHearUpdated(AActor* Actor, FAIStimulus Stimulus);

	// AI Controller�� Pawn ���� ���۽��� �Լ�, override�� ���� ������
	virtual void OnPossess(APawn* InPawn) override;

	// Properties
  public:
  protected:
	UPROPERTY(EditDefaultsOnly, Category = "AI|Control")
	class UBehaviorTree* BehaviorTreeAsset;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI|State")
	TObjectPtr<UContinuousStateComponent> State;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI|State")
	TObjectPtr<UShortTermStateComponent> Flag;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI|State")
	TObjectPtr<USenseComponent> SenseValue;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Moster|AI")
	TObjectPtr<UAIPerceptionComponent> AIPerception;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Moster|AI")
	TObjectPtr<UAISenseConfig_Sight> SightConfig;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Moster|AI")
	TObjectPtr<UAISenseConfig_Hearing> HearingConfig;
};
