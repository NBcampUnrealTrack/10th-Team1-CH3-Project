// 26/09/09 Copyright CH3 Team1 Jinho Song

// Base include
#include "Monster/AiController/MonsterAIController.h"

// Add include
#include "NavigationSystem.h"
#include "TimerManager.h"

#include "Monster/ActorComponent/ContinuousStateComponent.h"
#include "Monster/ActorComponent/SenseComponent.h"
#include "Monster/ActorComponent/ShortTermStateComponent.h"
#include "Monster/Enums/InfoEnums.h"
#include "Monster/Enums/StateEnums.h"
#include "Monster/MonsterCharacter/MonsterCharacter.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Hearing.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Player/Character/BOCharacter.h"

AMonsterAIController::AMonsterAIController()
{
	// ���� ������ ������Ʈ
	State = CreateDefaultSubobject<UContinuousStateComponent>(TEXT("State"));
	State->OnStateCast.AddUObject(this, &AMonsterAIController::FocusSetUp);

	// �÷��� ������Ʈ
	Flag = CreateDefaultSubobject<UShortTermStateComponent>(TEXT("Flag"));

	// ���� �� ������Ʈ
	SenseValue = CreateDefaultSubobject<USenseComponent>(TEXT("SenseValue"));

	AIPerception = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerception"));
	SetPerceptionComponent(*AIPerception);

	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));

	SightConfig->DetectionByAffiliation.bDetectEnemies = true;
	SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
	SightConfig->DetectionByAffiliation.bDetectFriendlies = true;

	AIPerception->SetDominantSense(SightConfig->GetSenseImplementation());

	HearingConfig = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("HearingConfig"));

	HearingConfig->DetectionByAffiliation.bDetectEnemies = true;
	HearingConfig->DetectionByAffiliation.bDetectNeutrals = true;
	HearingConfig->DetectionByAffiliation.bDetectFriendlies = true;
}

void AMonsterAIController::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	SenseValue->SenseSetup();

	SightConfig->SightRadius = SenseValue->GetSightSenseSize();
	SightConfig->LoseSightRadius = SenseValue->GetLoseSightSize();
	SightConfig->PeripheralVisionAngleDegrees = SenseValue->GetVisionAngleDegrees();
	SightConfig->SetMaxAge(SenseValue->GetMemorize());
	AIPerception->ConfigureSense(*SightConfig);

	HearingConfig->HearingRange = SenseValue->GetHearSenseSize();
	HearingConfig->SetMaxAge(SenseValue->GetMemorize());
	AIPerception->ConfigureSense(*HearingConfig);
}

void AMonsterAIController::EnableBehaviorTree()
{
	// Assets ���� ����
	if (!BehaviorTreeAsset)
	{
		return;
	}

	// ���� BT ������ �����ϴ� �Լ�
	RunBehaviorTree(BehaviorTreeAsset);
}

void AMonsterAIController::BeginPlay()
{
	Super::BeginPlay();
	AIPerception->OnTargetPerceptionUpdated.AddDynamic(this, &AMonsterAIController::OnTargetHearUpdated);
	EnableBehaviorTree();
}

void AMonsterAIController::OnTargetHearUpdated(AActor* Actor, FAIStimulus Stimulus)
{

	const float CurrentTime = GetWorld()->GetTimeSeconds();

	if (Stimulus.Type == UAISense::GetSenseID<UAISense_Hearing>())
	{
		if (Stimulus.WasSuccessfullySensed())
		{

			ABOCharacter* NoiseActor = Cast<ABOCharacter>(Actor);
			AMonsterCharacter* Monster = Cast<AMonsterCharacter>(GetPawn());

			FVector NoiseLocation = Stimulus.StimulusLocation;

			if (!NoiseActor)
			{
				return;
			}

			PlantFlag(EFlag::Hearing, CurrentTime);
			SetTargetPoint(NoiseLocation);
			SetTarget(NoiseActor);
		}
	}
}

void AMonsterAIController::OnPossess(APawn* InPawn)
{
	// �θ� Ŭ������ ���� ���
	Super::OnPossess(InPawn);

	if (InPawn)
	{
		SenseValue->SetSpawnPoint(InPawn->GetActorLocation());
	}
}

// ��������Ʈ�� ���� �þ� ����
void AMonsterAIController::FocusSetUp(const EMonsterState& Input)
{
	bool Focus = true;

	if (Input == EMonsterState::Chase ||
		Input == EMonsterState::Attack)
	{
		Focus = false;
	}

	if (AMonsterCharacter* AICharacter = Cast<AMonsterCharacter>(GetPawn()))
	{
		bAllowStrafe = !Focus;
		AICharacter->FocusSetUp(Focus);
	}
}

// ������ ���Ͽ�

// Event

void AMonsterAIController::PlantFlag(FFlagInfo FlagInfo)
{
	Flag->PlantFlag(FlagInfo);
}

void AMonsterAIController::PlantFlag(EFlag PFlag, float Time)
{
	Flag->PlantFlag(PFlag, Time);
}

void AMonsterAIController::PlantFlag(EFlag SFlag, float Time, bool Type)
{
	Flag->PlantFlag(SFlag, Time, Type);
}

bool AMonsterAIController::FoldFlags(EFlag Target)
{
	return Flag->FoldFlags(Target);
}

bool AMonsterAIController::FoldFlags(EFlag Target, bool& Type)
{
	return Flag->FoldFlags(Target, Type);
}

// Continuous State

void AMonsterAIController::OnStandOff()
{
	State->OnStandOff();
}

bool AMonsterAIController::StandOffGetPosition() const
{
	return State->StandOffGetPosition();
}

void AMonsterAIController::StateChange(EMonsterState Input)
{
	State->StateChange(Input);
}

void AMonsterAIController::StateChange(EMonsterState Input, float HoldTime)
{
	State->StateChange(Input, HoldTime);
}

EMonsterState AMonsterAIController::GetState() const
{
	return State->GetState();
}

EMonsterState AMonsterAIController::GetBeforeState() const
{
	return State->GetBeforeState();
}

bool AMonsterAIController::IsContinueState() const
{
	return State->IsContinueState();
}

// Sense Code

void AMonsterAIController::SetTarget(ABOCharacter* Target)
{
	SenseValue->SetTarget(Target);
}

ABOCharacter* AMonsterAIController::GetTarget() const
{
	return SenseValue->GetTarget();
}

void AMonsterAIController::SetTargetPoint(FVector Point)
{
	SenseValue->SetTargetPoint(Point);
}

FVector AMonsterAIController::GetTargetPoint() const
{
	return SenseValue->GetTargetPoint();
}

void AMonsterAIController::SetEQSPoint(FVector Point)
{
	SenseValue->SetEQSPoint(Point);
}

FVector AMonsterAIController::GetEQSPoint() const
{
	return SenseValue->GetEQSPoint();
}

FVector AMonsterAIController::GetSpawnPoint() const
{
	return SenseValue->GetSpawnPoint();
}
